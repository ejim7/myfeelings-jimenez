package utilities

data class Emociones(var nombre:String, var porcentaje:Float, var color: Int, var total:Float)